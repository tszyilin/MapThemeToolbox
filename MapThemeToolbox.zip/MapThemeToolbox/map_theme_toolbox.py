# -*- coding: utf-8 -*-
"""
Map Theme Toolbox — combined plugin  (QGIS 3.22+ and QGIS 4.x)
Toolbar buttons:
  1. Modify Theme Layers       (icon_modify.png)
  2. Repair Unavailable Layers (icon_repair.png)
  3. Refresh Layer Sources     (circular-arrow icon)
  4. Theme Presenter           (icon_present.png)
  5. Sync Setup                (icon_sync.png)
  6. Quick Sync                (icon_sync_on/off)
  7. Auto-Save                 (clock icon)
Layout designer atlas toolbar:
  Export Selected Atlas Pages, Quick Sync
"""

import os
import math
from qgis.PyQt.QtWidgets import (
    QAction, QMessageBox, QDialog, QApplication, QToolBar, QProgressDialog,
)
from qgis.PyQt.QtGui import (
    QIcon, QPixmap, QPainter, QColor, QPen, QBrush, QFont, QPolygonF, QTransform,
)
from qgis.PyQt.QtCore import Qt, QTimer, QPointF
from qgis.core import QgsApplication, QgsProject, QgsLayoutItemMap

from .compat import (
    Transparent, NoBrush, NoPen, SolidLine, RoundCap,
    Antialiasing, RightDock, Button_Yes, Button_No, Accepted, WindowModal,
)
from .processing_provider import MapThemeToolboxProvider
from .sync_state import REGISTRY
from .autosave_manager import AutoSaveManager

MENU = "&Map Theme Toolbox"


class MapThemeToolbox:
    def __init__(self, iface):
        self.iface    = iface
        self.provider = None
        self.actions  = []
        self.toolbar  = self.iface.addToolBar("Map Theme Toolbox")
        self.toolbar.setObjectName("MapThemeToolboxToolbar")
        self._quick_sync_action  = None
        self._layout_qs_actions  = {}   # id(designer) -> QAction
        self._layout_export_actions = {}   # id(designer) -> QAction
        self._present_dock      = None
        self._autosave           = None
        self._autosave_action    = None

    def _icon(self, name):
        path = os.path.join(os.path.dirname(__file__), name)
        return QIcon(path) if os.path.exists(path) else QIcon()

    def _add_action(self, icon_file, label, slot, tooltip=""):
        act = QAction(self._icon(icon_file), label, self.iface.mainWindow())
        act.setToolTip(tooltip or label)
        act.triggered.connect(slot)
        self.toolbar.addAction(act)
        self.iface.addPluginToMenu(MENU, act)
        self.actions.append(act)
        return act

    def _make_autosave_icon(self, enabled):
        SIZE = 20
        pix  = QPixmap(SIZE, SIZE)
        pix.fill(Transparent)

        p = QPainter(pix)
        p.setRenderHint(Antialiasing)

        col = QColor("#27ae60") if enabled else QColor("#95a5a6")
        cx = cy = SIZE / 2.0
        r  = SIZE / 2.0 - 1.5

        p.setPen(QPen(col, 1.8))
        p.setBrush(NoBrush)
        p.drawEllipse(QPointF(cx, cy), r, r)

        pen = QPen(col, 1.8, SolidLine, RoundCap)
        p.setPen(pen)
        ah = math.radians(-60)
        p.drawLine(QPointF(cx, cy),
                   QPointF(cx + r * 0.50 * math.sin(ah),
                            cy - r * 0.50 * math.cos(ah)))
        p.drawLine(QPointF(cx, cy), QPointF(cx, cy - r * 0.75))

        p.setPen(NoPen)
        p.setBrush(QBrush(col))
        p.drawEllipse(QPointF(cx, cy), 1.5, 1.5)
        p.end()
        return QIcon(pix)

    def _make_refresh_icon(self):
        SIZE = 20
        pix  = QPixmap(SIZE, SIZE)
        pix.fill(Transparent)

        p = QPainter(pix)
        p.setRenderHint(Antialiasing)

        col = QColor("#2980b9")
        cx = cy = SIZE / 2.0
        r  = SIZE / 2.0 - 3.0

        # Open arc from 60° round to 360° (angles in 1/16 degree, CCW from 3 o'clock)
        p.setPen(QPen(col, 2.0, SolidLine, RoundCap))
        p.setBrush(NoBrush)
        p.drawArc(int(cx - r), int(cy - r), int(2 * r), int(2 * r), 60 * 16, 300 * 16)

        # Arrowhead at the arc's 60° end, pointing clockwise into the gap
        a  = math.radians(60)
        px, py = cx + r * math.cos(a), cy - r * math.sin(a)
        dx, dy = math.sin(a), math.cos(a)      # clockwise tangent (screen coords)
        nx, ny = -dy, dx                       # normal
        p.setPen(NoPen)
        p.setBrush(QBrush(col))
        p.drawPolygon(QPolygonF([
            QPointF(px + 3.5 * dx, py + 3.5 * dy),
            QPointF(px - 1.5 * dx + 3.2 * nx, py - 1.5 * dy + 3.2 * ny),
            QPointF(px - 1.5 * dx - 3.2 * nx, py - 1.5 * dy - 3.2 * ny),
        ]))
        p.end()
        return QIcon(pix)

    def initGui(self):
        self.provider = MapThemeToolboxProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        self._add_action("icon_modify.png", "Modify Theme Layers",
                         self.run_modify, "Toggle mutual layer visibility across themes")
        self._add_action("icon_repair.png", "Repair Unavailable Layers",
                         self.run_repair,
                         "Batch re-link broken layer paths after moving project files")

        refresh_act = QAction(self._make_refresh_icon(), "Refresh All Layer Sources",
                              self.iface.mainWindow())
        refresh_act.setToolTip(
            "Reconnect every layer to its data source\n"
            "(fixes 'IReadBlock failed' after a network/server drop)"
        )
        refresh_act.triggered.connect(self.run_refresh_sources)
        self.toolbar.addAction(refresh_act)
        self.iface.addPluginToMenu(MENU, refresh_act)
        self.actions.append(refresh_act)

        self._add_action("icon_present.png", "Theme Presenter",
                         self.run_present, "Apply any map theme with a single click")
        self._add_action("icon_sync.png", "Sync Setup (Excel/CSV ↔ GeoPackage)",
                         self.run_sync, "Open the sync connection setup dialog")

        self._quick_sync_action = QAction(
            self._icon("icon_sync_off.png"),
            "Quick Sync  (not connected)",
            self.iface.mainWindow()
        )
        self._quick_sync_action.setToolTip(
            "Quick Sync: no connection set up yet.\nClick 'Sync Setup' first to connect a file."
        )
        self._quick_sync_action.setEnabled(False)
        self._quick_sync_action.triggered.connect(self.run_quick_sync)
        self.toolbar.addAction(self._quick_sync_action)
        self.iface.addPluginToMenu(MENU, self._quick_sync_action)
        self.actions.append(self._quick_sync_action)

        REGISTRY.register_callback(self._on_connection_changed)
        self._on_connection_changed()
        self.iface.layoutDesignerOpened.connect(self._on_layout_designer_opened)
        for designer in self.iface.openLayoutDesigners():
            self._inject_layout_qs(designer)

        self.toolbar.addSeparator()
        self._autosave = AutoSaveManager(self.iface)
        self._autosave_action = QAction(
            self._make_autosave_icon(self._autosave.enabled),
            "Auto-Save  (off)",
            self.iface.mainWindow()
        )
        self._autosave_action.setToolTip("Auto-Save is OFF — click to configure")
        self._autosave_action.triggered.connect(self.run_autosave)
        self.toolbar.addAction(self._autosave_action)
        self.iface.addPluginToMenu(MENU, self._autosave_action)
        self.actions.append(self._autosave_action)

        self._autosave.register_callback(self._on_autosave_changed)
        self._on_autosave_changed()

        if self._autosave.show_on_start:
            QTimer.singleShot(800, self.run_autosave)

    def unload(self):
        try:
            self.iface.layoutDesignerOpened.disconnect(self._on_layout_designer_opened)
        except Exception:
            pass
        for act in list(self._layout_qs_actions.values()):
            act.deleteLater()
        self._layout_qs_actions.clear()
        for act in list(self._layout_export_actions.values()):
            act.deleteLater()
        self._layout_export_actions.clear()
        REGISTRY.unregister_callback(self._on_connection_changed)
        REGISTRY.cleanup()
        if self._autosave:
            self._autosave.stop()
        for act in self.actions:
            self.iface.removePluginMenu(MENU, act)
            self.iface.removeToolBarIcon(act)
        del self.toolbar
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
        if self._present_dock:
            self.iface.removeDockWidget(self._present_dock)
            self._present_dock.deleteLater()
            self._present_dock = None

    def _sync_layout_action(self, act):
        connected = REGISTRY.connected_list()
        if connected:
            act.setIcon(self._icon("icon_sync_on.png"))
            if len(connected) == 1:
                label = connected[0].name
                tip   = (f"Quick Sync — click to push data now\n"
                         f"Connection: {connected[0].name}\n"
                         f"File:  {os.path.basename(connected[0].file_path or '')}\n"
                         f"Layer: {connected[0].layer_name}")
            else:
                label = f"{len(connected)} connected"
                tip   = "Quick Sync — will sync all connected connections:\n" + \
                        "\n".join(f"  • {c.name}" for c in connected)
            act.setText(f"Quick Sync  ✔ {label}")
            act.setToolTip(tip)
            act.setEnabled(True)
        else:
            act.setIcon(self._icon("icon_sync_off.png"))
            act.setText("Quick Sync  (not connected)")
            act.setToolTip(
                "Quick Sync: no connections set up yet.\n"
                "Click 'Sync Setup' first to connect a file."
            )
            act.setEnabled(False)

    def _on_connection_changed(self):
        if self._quick_sync_action is None:
            return
        self._sync_layout_action(self._quick_sync_action)
        for act in list(self._layout_qs_actions.values()):
            self._sync_layout_action(act)

    def _make_copy_extent_icon(self):
        SIZE = 20
        pix = QPixmap(SIZE, SIZE)
        pix.fill(Transparent)
        p = QPainter(pix)
        p.setRenderHint(Antialiasing)
        col = QColor("#2c3e50")
        p.setPen(QPen(col, 1.6))
        p.setBrush(NoBrush)
        p.drawRect(3, 5, 14, 12)
        f = QFont()
        f.setPointSizeF(6.5)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QPen(QColor("#c0392b"), 1))
        p.drawText(pix.rect().adjusted(0, 1, 0, 0), Qt.AlignCenter, "XY")
        p.end()
        return QIcon(pix)

    def _inject_atlas_export(self, designer):
        key = id(designer)
        if key in self._layout_export_actions:
            return
        from .dialog_atlas_export import designer_print_layout
        layout = designer_print_layout(designer)
        if layout is None:    # reports share this designer but have no atlas
            return
        # Export arrow turned 90° clockwise so it points right
        pix = QPixmap(os.path.join(os.path.dirname(__file__), "icon_export.png"))
        icon = QIcon(pix.transformed(QTransform().rotate(90)))
        act = QAction(icon, "Export Selected Atlas Pages…",
                      designer.window())
        act.setObjectName("mtt_export_selected_pages_action")
        act.setToolTip("Export Selected Atlas Pages\n"
                       "Choose which pages to export instead of the entire atlas")
        act.triggered.connect(lambda _=False, d=designer: self.run_atlas_export(d))
        atlas = layout.atlas()
        act.setEnabled(atlas.enabled())
        atlas.toggled.connect(act.setEnabled)

        # Appended just before Quick Sync, which _inject_layout_qs adds next
        designer.atlasToolbar().addAction(act)

        self._layout_export_actions[key] = act

        def _cleanup(_obj, _key=key):
            self._layout_export_actions.pop(_key, None)

        designer.destroyed.connect(_cleanup)

    def run_atlas_export(self, designer):
        from .dialog_atlas_export import run_atlas_export
        run_atlas_export(designer)

    def _inject_layout_qs(self, designer):
        self._inject_atlas_export(designer)

        key = id(designer)
        if key in self._layout_qs_actions:
            return
        act = QAction(self._icon("icon_sync_off.png"), "Quick Sync  (not connected)", designer.window())
        act.setEnabled(False)
        act.triggered.connect(self.run_quick_sync)
        designer.atlasToolbar().addAction(act)

        self._layout_qs_actions[key] = act

        def _cleanup(_obj, _key=key, _act=act):
            self._layout_qs_actions.pop(_key, None)
            try:
                _act.deleteLater()
            except RuntimeError:
                pass

        designer.destroyed.connect(_cleanup)
        self._sync_layout_action(act)

        self._inject_map_widget_button(designer)

    def _inject_map_widget_button(self, designer):
        from qgis.PyQt.QtWidgets import QWidget

        def scan_and_inject():
            try:
                win = designer.window()
            except Exception:
                return
            if win is None:
                return
            widgets = [w for w in win.findChildren(QWidget)
                       if w.metaObject().className() == "QgsLayoutMapWidget"]
            for w in widgets:
                tbs = w.findChildren(QToolBar)
                if not tbs:
                    continue
                tb = tbs[0]
                if tb.property("mtt_copy_extent_injected"):
                    continue
                copy_act = QAction(self._make_copy_extent_icon(),
                                   "Copy Map Extent (row for Excel)", tb)
                copy_act.setObjectName("mtt_copy_extent_action")
                copy_act.setToolTip(
                    "Copy this map item's extent to the clipboard as\n"
                    "xmin<TAB>ymin<TAB>xmax<TAB>ymax — paste as one row in Excel."
                )
                copy_act.triggered.connect(
                    lambda _=False, d=designer: self._run_copy_extent_from_designer(d))
                tb.addSeparator()
                tb.addAction(copy_act)
                tb.setProperty("mtt_copy_extent_injected", True)

        try:
            layout = designer.layout()
            if layout is not None:
                layout.selectionChanged.connect(
                    lambda: QTimer.singleShot(0, scan_and_inject))
        except Exception:
            pass
        QTimer.singleShot(0, scan_and_inject)

        poll = QTimer(designer.window())
        poll.setInterval(500)
        poll.timeout.connect(scan_and_inject)
        poll.start()
        designer.destroyed.connect(lambda _=None, t=poll: t.stop())

    def _run_copy_extent_from_designer(self, designer):
        map_item = None
        try:
            layout = designer.layout()
            if layout is not None:
                for it in layout.selectedLayoutItems():
                    if isinstance(it, QgsLayoutItemMap):
                        map_item = it
                        break
                if map_item is None:
                    for it in layout.items():
                        if isinstance(it, QgsLayoutItemMap):
                            map_item = it
                            break
        except Exception:
            pass
        if map_item is None:
            QMessageBox.warning(self.iface.mainWindow(), "Copy Map Extent",
                                "Could not read the map item from this panel.")
            return
        ext = map_item.extent()
        text = "\t".join(f"{v:.3f}" for v in
                        (ext.xMinimum(), ext.yMinimum(), ext.xMaximum(), ext.yMaximum()))
        QApplication.clipboard().setText(text)
        try:
            self.iface.messageBar().pushSuccess("Copied Map Extent", text)
        except Exception:
            pass

    def _on_layout_designer_opened(self, designer):
        self._inject_layout_qs(designer)

    def _tc(self):
        return QgsProject.instance().mapThemeCollection()

    def _require_themes(self):
        tc = self._tc()
        themes = tc.mapThemes()
        if not themes:
            QMessageBox.information(self.iface.mainWindow(), "No Themes",
                                    "No map themes found in the current project.")
            return None, None
        return tc, themes

    def run_modify(self):
        from .dialog_modify_layers import ThemeSelectDialog, LayerToggleDialog
        tc, all_themes = self._require_themes()
        if all_themes is None: return
        project = QgsProject.instance()
        root  = project.layerTreeRoot()
        model = self.iface.layerTreeView().layerTreeModel()
        dlg1 = ThemeSelectDialog(all_themes, parent=self.iface.mainWindow())
        if dlg1.exec() != Accepted: return
        selected = dlg1.selected_themes()
        if not selected:
            QMessageBox.information(self.iface.mainWindow(), "Nothing Selected",
                                    "Please select at least one theme.")
            return
        valid = [t for t in selected if t in all_themes]
        if not valid: return

        def save_state():
            state = tc.createThemeFromCurrentState(root, model)
            tmp = "__mtt_tmp__"
            if tmp in tc.mapThemes(): tc.removeMapTheme(tmp)
            tc.insert(tmp, state)
            return tmp

        def restore_state(tmp):
            tc.applyTheme(tmp, root, model)
            tc.removeMapTheme(tmp)

        tmp = save_state()
        try:
            sets = []
            for t in valid:
                tc.applyTheme(t, root, model)
                visible = set()
                for tl in root.findLayers():
                    if tl.itemVisibilityChecked():
                        l = tl.layer()
                        if l: visible.add(l.name())
                sets.append(visible)
        finally:
            restore_state(tmp)

        common = sorted(set.intersection(*sets)) if len(sets) > 1 else sorted(sets[0])
        all_layer_names = [l.name() for l in project.mapLayers().values()]
        if not common:
            QMessageBox.information(self.iface.mainWindow(), "No Mutual Layers",
                                    "No layers are visible in ALL selected themes.\n"
                                    "You can still add layers manually in the next step.")
        dlg2 = LayerToggleDialog(common, valid, all_layer_names, parent=self.iface.mainWindow())
        if dlg2.exec() != Accepted: return
        to_hide = dlg2.layers_to_hide()
        to_show = [l for l in dlg2.layers_to_show() if l not in common]
        if not to_hide and not to_show:
            QMessageBox.information(self.iface.mainWindow(), "No Changes", "Nothing to update.")
            return
        lines = []
        if to_hide: lines.append(f"Turn OFF ({len(to_hide)}): " + ", ".join(to_hide))
        if to_show: lines.append(f"Turn ON  ({len(to_show)}): " + ", ".join(to_show))
        reply = QMessageBox.question(
            self.iface.mainWindow(), "Confirm Update",
            f"Apply to {len(valid)} theme(s):\n\n" + "\n".join(lines),
            Button_Yes | Button_No, Button_No
        )
        if reply != Button_Yes: return
        tmp2 = save_state()
        try:
            for t in valid:
                tc.applyTheme(t, root, model)
                for ln in to_hide:
                    for l in project.mapLayersByName(ln):
                        node = root.findLayer(l.id())
                        if node: node.setItemVisibilityChecked(False)
                for ln in to_show:
                    for l in project.mapLayersByName(ln):
                        node = root.findLayer(l.id())
                        if node: node.setItemVisibilityChecked(True)
                tc.update(t, tc.createThemeFromCurrentState(root, model))
        finally:
            restore_state(tmp2)
        parts = []
        if to_hide: parts.append(f"turned OFF {len(to_hide)} layer(s)")
        if to_show: parts.append(f"turned ON {len(to_show)} extra layer(s)")
        QMessageBox.information(self.iface.mainWindow(), "Done",
                                f"Updated {len(valid)} theme(s) — " + " and ".join(parts) + ".")

    def run_repair(self):
        from .dialog_repair_layers import RepairLayersDialog
        RepairLayersDialog(parent=self.iface.mainWindow()).exec()

    def run_refresh_sources(self):
        canvas = self.iface.mapCanvas()
        # Stop render threads so nothing is still reading through the old handles
        canvas.stopRendering()

        layers = list(QgsProject.instance().mapLayers().values())
        total  = len(layers)
        reloaded, reconnected = 0, 0
        failed = []     # (name, reason, source)
        canceled = False

        progress = QProgressDialog("Preparing…", "Cancel", 0, total, self.iface.mainWindow())
        progress.setWindowTitle("Refresh Layer Sources")
        progress.setWindowModality(WindowModal)
        progress.setMinimumDuration(0)
        progress.setMinimumWidth(420)
        progress.setValue(0)
        from .dialog_refresh_summary import missing_reason
        try:
            for i, layer in enumerate(layers):
                if progress.wasCanceled():
                    canceled = True
                    break
                # Show the layer name *before* reloading, so a slow network
                # layer is visible while it blocks
                progress.setLabelText(f"Reconnecting layer {i + 1} of {total}:\n{layer.name()}")
                progress.setValue(i)
                QApplication.processEvents()
                try:
                    if layer.isValid():
                        # GDAL/OGR providers close and reopen the dataset on reload
                        layer.reload()
                        reloaded += 1
                    else:
                        layer.setDataSource(layer.source(), layer.name(), layer.providerType())
                        if layer.isValid():
                            reconnected += 1
                        else:
                            failed.append((layer.name(), missing_reason(layer), layer.source()))
                            continue
                    layer.triggerRepaint()
                except Exception as exc:
                    failed.append((layer.name(), missing_reason(layer, exc), layer.source()))

            progress.setLabelText("Redrawing map…")
            progress.setValue(total)
            QApplication.processEvents()
            # Not refreshAllLayers(): that calls reload() on every layer a second time
            canvas.clearCache()
            canvas.refresh()
            for designer in self.iface.openLayoutDesigners():
                try:
                    designer.layout().refresh()
                except Exception:
                    pass
        finally:
            progress.close()

        skipped = total - reloaded - reconnected - len(failed)
        summary = f"Reloaded {reloaded} layer(s)"
        if reconnected:
            summary += f", reconnected {reconnected}"
        if canceled:
            summary += f"  |  canceled, {skipped} skipped"
        if failed:
            self.iface.messageBar().pushWarning(
                "Refresh Layer Sources",
                f"{summary}  |  {len(failed)} still unavailable")
            from .dialog_refresh_summary import RefreshSummaryDialog
            dlg = RefreshSummaryDialog(failed, reloaded, reconnected,
                                       skipped if canceled else 0,
                                       parent=self.iface.mainWindow())
            dlg.exec()
            if dlg.open_repair:
                self.run_repair()
        elif canceled:
            self.iface.messageBar().pushInfo("Refresh Layer Sources", summary)
        else:
            self.iface.messageBar().pushSuccess("Refresh Layer Sources", summary)

    def run_present(self):
        from .dialog_apply_theme import ThemePresenterDock
        if self._present_dock is None:
            self._present_dock = ThemePresenterDock(self.iface, parent=self.iface.mainWindow())
            self.iface.addDockWidget(RightDock, self._present_dock)
            return
        if self._present_dock.isVisible():
            self._present_dock.hide()
        else:
            self._present_dock.show()
            self._present_dock.raise_()

    def run_sync(self):
        from .dialog_sync_table import SyncTableDialog
        SyncTableDialog(self.iface, parent=self.iface.mainWindow()).exec()

    def _plugin_version(self):
        try:
            path = os.path.join(os.path.dirname(__file__), "metadata.txt")
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip().startswith("version="):
                        return line.split("=", 1)[1].strip()
        except Exception:
            pass
        return "?"

    def _on_autosave_changed(self):
        if self._autosave_action is None or self._autosave is None:
            return
        enabled = self._autosave.enabled
        self._autosave_action.setIcon(self._make_autosave_icon(enabled))
        if enabled:
            ivl = self._autosave.interval
            mins, secs = divmod(ivl, 60)
            label = f"{mins}m {secs:02d}s" if mins else f"{secs}s"
            self._autosave_action.setText(f"Auto-Save  ✔ {label}")
            self._autosave_action.setToolTip(f"Auto-Save: ON — every {label}\nClick to configure.")
        else:
            self._autosave_action.setText("Auto-Save  (off)")
            self._autosave_action.setToolTip("Auto-Save is OFF — click to configure.")

    def run_autosave(self):
        from .dialog_autosave import AutoSaveDialog
        AutoSaveDialog(self._autosave, parent=self.iface.mainWindow()).exec()

    def run_quick_sync(self):
        connected = REGISTRY.connected_list()
        if not connected:
            QMessageBox.information(self.iface.mainWindow(), "Not Connected",
                "No connections set up yet.\nClick 'Sync Setup' to connect a file first.")
            return
        from .dialog_sync_table import perform_sync
        results = []
        all_ok  = True
        for conn in connected:
            success, msg = perform_sync(conn, self.iface)
            results.append(f"{conn.name}: {msg}")
            if not success:
                all_ok = False
        summary = "  |  ".join(results)
        if all_ok:
            self.iface.messageBar().pushSuccess("Quick Sync", summary)
        else:
            self.iface.messageBar().pushWarning("Quick Sync (some errors)", summary)
