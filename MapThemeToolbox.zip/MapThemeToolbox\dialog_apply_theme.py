# -*- coding: utf-8 -*-
"""
Theme Presenter — dockable panel.  QGIS 3.22+ and QGIS 4.x.
"""

import json
import os

from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QGridLayout,
    QLabel, QTreeWidget, QTreeWidgetItem,
    QListWidget, QListWidgetItem,
    QLineEdit, QPushButton, QAbstractItemView,
    QInputDialog, QMessageBox,
    QDialog, QDialogButtonBox,
    QMenu,
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import QgsProject

from .compat import (
    UserRole, UserRole1,
    InternalMove, MoveAction, OnItem,
    ItemIsEnabled, ItemIsSelectable, ItemIsDragEnabled, ItemIsDropEnabled,
    SingleSelection, ExtendedSelection,
    LeftDock, RightDock, BottomDock,
    DockMovable, DockFloatable, DockClosable,
    Button_Yes, Button_No, Button_Ok, Button_Cancel,
    Accepted,
)

TREE_VAR        = "mtt_tree"
_LEGACY_GRP     = "mtt_theme_groups"
_LEGACY_ORDER   = "mtt_theme_order"
GROUP_NAME_ROLE = UserRole1


# ── Drag-and-drop tree ────────────────────────────────────────────────────────

class ThemeTree(QTreeWidget):
    def __init__(self, dock, parent=None):
        super().__init__(parent)
        self._dock = dock
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(InternalMove)
        self.setDefaultDropAction(MoveAction)

    def dropEvent(self, event):
        target    = self.itemAt(event.pos())
        indicator = self.dropIndicatorPosition()
        dragged   = self.currentItem()

        if dragged is None:
            event.ignore()
            return

        if (target is not None
                and target.data(0, UserRole) is not None
                and indicator == OnItem):
            event.ignore()
            return

        if dragged.data(0, UserRole) is None:
            ancestor = target
            while ancestor is not None:
                if ancestor is dragged:
                    event.ignore()
                    return
                ancestor = ancestor.parent()

        super().dropEvent(event)
        self._dock._rebuild_from_tree()


# ── Theme Presenter dock ──────────────────────────────────────────────────────

class ThemePresenterDock(QDockWidget):

    def __init__(self, iface, parent=None):
        super().__init__("Theme Presenter", parent)
        self.iface          = iface
        self._current_theme = None

        self.setAllowedAreas(LeftDock | RightDock | BottomDock)
        self.setFeatures(DockMovable | DockFloatable | DockClosable)

        self._build_ui()
        self._populate()

    def _build_ui(self):
        container = QWidget()
        layout    = QVBoxLayout(container)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(4)

        hdr = QLabel("Click theme to apply · Drag themes or groups to reorder / nest.")
        hdr.setWordWrap(True)
        hdr.setStyleSheet("color:#555; font-size:10px; padding-bottom:2px;")
        layout.addWidget(hdr)

        self._search = QLineEdit()
        self._search.setPlaceholderText("🔍  Filter themes…")
        self._search.setClearButtonEnabled(True)
        self._search.textChanged.connect(self._filter)
        layout.addWidget(self._search)

        self._list = ThemeTree(self)
        self._list.setHeaderHidden(True)
        self._list.setSelectionMode(SingleSelection)
        self._list.setAlternatingRowColors(True)
        self._list.setIndentation(16)
        self._list.itemClicked.connect(self._on_item_clicked)
        self._list.setContextMenuPolicy(Qt.CustomContextMenu)
        self._list.customContextMenuRequested.connect(self._on_context_menu)
        layout.addWidget(self._list)

        btn_grid = QGridLayout()
        btn_grid.setSpacing(4)
        self._btn_add     = QPushButton("➕  Add")
        self._btn_rename  = QPushButton("✏️  Rename")
        self._btn_replace = QPushButton("🔄  Replace")
        self._btn_delete  = QPushButton("🗑  Delete")
        self._btn_add.setToolTip("Create a new theme from the current canvas state")
        self._btn_rename.setToolTip("Rename the selected theme or group")
        self._btn_replace.setToolTip("Overwrite selected theme with current canvas state")
        self._btn_delete.setToolTip("Delete the selected theme from QGIS")
        self._btn_delete.setStyleSheet("color:#c0392b;")
        self._btn_add.clicked.connect(self._on_add)
        self._btn_rename.clicked.connect(self._on_rename)
        self._btn_replace.clicked.connect(self._on_replace)
        self._btn_delete.clicked.connect(self._on_delete)
        btn_grid.addWidget(self._btn_add,     0, 0)
        btn_grid.addWidget(self._btn_rename,  0, 1)
        btn_grid.addWidget(self._btn_replace, 1, 0)
        btn_grid.addWidget(self._btn_delete,  1, 1)
        layout.addLayout(btn_grid)

        grp_grid = QGridLayout()
        grp_grid.setSpacing(4)
        self._btn_group   = QPushButton("📁  Create Group")
        self._btn_session = QPushButton("💾  Export Session…")
        self._btn_group.setToolTip(
            "Assign themes to a named group.\n"
            "Drag group headers to reorder or nest as sub-groups.")
        self._btn_session.setToolTip(
            "Export / import a self-contained snapshot of all themes\n"
            "(layers + styles + Presenter tree) as a JSON file.")
        self._btn_group.clicked.connect(self._on_create_group)
        self._btn_session.clicked.connect(self._on_session)
        grp_grid.addWidget(self._btn_group,   0, 0)
        grp_grid.addWidget(self._btn_session, 0, 1)
        layout.addLayout(grp_grid)

        self._status = QLabel("No theme applied yet.")
        self._status.setWordWrap(True)
        self._status.setStyleSheet(
            "background:#d4edda; color:#155724; border:1px solid #c3e6cb; "
            "border-radius:4px; padding:5px; font-size:10px;"
        )
        layout.addWidget(self._status)

        refresh_btn = QPushButton("↻  Refresh List")
        refresh_btn.setToolTip("Reload theme list from project")
        refresh_btn.clicked.connect(self._populate)
        layout.addWidget(refresh_btn)

        self.setWidget(container)

    # ── Tree JSON persistence ─────────────────────────────────────────────────

    def _load_tree(self):
        vars_ = QgsProject.instance().customVariables()
        raw = vars_.get(TREE_VAR, "")
        if raw:
            try:
                return json.loads(raw)
            except Exception:
                pass
        grp_raw   = vars_.get(_LEGACY_GRP, "")
        order_raw = vars_.get(_LEGACY_ORDER, "")
        if grp_raw or order_raw:
            try:
                groups_map = json.loads(grp_raw) if grp_raw else {}
            except Exception:
                groups_map = {}
            try:
                order = json.loads(order_raw) if order_raw else []
            except Exception:
                order = []
            buckets = {}
            root_themes = []
            for name in order:
                g = groups_map.get(name)
                if g:
                    buckets.setdefault(g, []).append({"type": "theme", "name": name})
                else:
                    root_themes.append({"type": "theme", "name": name})
            children = [
                {"type": "group", "name": g, "children": ts}
                for g, ts in buckets.items()
            ] + root_themes
            return {"type": "root", "children": children}
        return {"type": "root", "children": []}

    def _save_tree(self, tree):
        v = QgsProject.instance().customVariables()
        v[TREE_VAR] = json.dumps(tree, ensure_ascii=False)
        QgsProject.instance().setCustomVariables(v)

    # ── Tree helpers ──────────────────────────────────────────────────────────

    def _collect_themes(self, node):
        if node["type"] == "theme":
            return {node["name"]}
        result = set()
        for child in node.get("children", []):
            result |= self._collect_themes(child)
        return result

    def _clean_tree(self, node, valid):
        if node["type"] == "theme":
            return node if node["name"] in valid else None
        if "children" in node:
            node["children"] = [
                r for r in (self._clean_tree(c, valid) for c in node["children"])
                if r is not None
            ]
        return node

    def _remove_themes_from_tree(self, node, names):
        if "children" not in node:
            return
        node["children"] = [
            c for c in node["children"]
            if not (c["type"] == "theme" and c["name"] in names)
        ]
        for c in node["children"]:
            self._remove_themes_from_tree(c, names)

    def _rename_theme_in_tree(self, node, old, new):
        if node["type"] == "theme" and node["name"] == old:
            node["name"] = new
        for c in node.get("children", []):
            self._rename_theme_in_tree(c, old, new)

    def _rename_group_in_tree(self, node, old, new):
        for c in node.get("children", []):
            if c["type"] == "group" and c["name"] == old:
                c["name"] = new
            self._rename_group_in_tree(c, old, new)

    def _remove_group_from_tree(self, node, name):
        if "children" not in node:
            return
        node["children"] = [
            c for c in node["children"]
            if not (c["type"] == "group" and c["name"] == name)
        ]
        for c in node["children"]:
            self._remove_group_from_tree(c, name)

    def _find_top_group(self, tree, name):
        for c in tree.get("children", []):
            if c["type"] == "group" and c["name"] == name:
                return c
        return None

    def _build_groups_map(self, node):
        result = {}
        if node["type"] == "group":
            for c in node.get("children", []):
                if c["type"] == "theme":
                    result[c["name"]] = node["name"]
                else:
                    result.update(self._build_groups_map(c))
        elif node["type"] == "root":
            for c in node.get("children", []):
                result.update(self._build_groups_map(c))
        return result

    def _is_theme_grouped(self, name):
        return name in self._build_groups_map(self._load_tree())

    def _rebuild_from_tree(self):
        root_item = self._list.invisibleRootItem()
        children  = [
            self._item_to_node(root_item.child(i))
            for i in range(root_item.childCount())
        ]
        tree = {"type": "root", "children": [n for n in children if n]}
        all_themes = set(self._tc().mapThemes())
        in_tree    = self._collect_themes(tree)
        for name in sorted(all_themes - in_tree, key=str.casefold):
            tree["children"].append({"type": "theme", "name": name})
        self._save_tree(tree)
        self._populate()

    def _item_to_node(self, item):
        theme_name = item.data(0, UserRole)
        if theme_name is not None:
            return {"type": "theme", "name": theme_name}
        group_name = item.data(0, GROUP_NAME_ROLE)
        if not group_name:
            return None
        children = [self._item_to_node(item.child(i)) for i in range(item.childCount())]
        return {"type": "group", "name": group_name, "children": [n for n in children if n]}

    # ── Core helpers ──────────────────────────────────────────────────────────

    def _tc(self):    return QgsProject.instance().mapThemeCollection()
    def _root(self):  return QgsProject.instance().layerTreeRoot()
    def _model(self): return self.iface.layerTreeView().layerTreeModel()

    def _selected_theme(self):
        item = self._list.currentItem()
        return item.data(0, UserRole) if item else None

    def _selected_group(self):
        item = self._list.currentItem()
        return item.data(0, GROUP_NAME_ROLE) if item else None

    def _require_theme_selection(self):
        name = self._selected_theme()
        if not name:
            QMessageBox.warning(self, "No Theme Selected",
                                "Please click a theme (not a group) in the list first.")
        return name

    # ── Populate ──────────────────────────────────────────────────────────────

    def _collect_collapsed_groups(self):
        collapsed = set()
        def walk(item, path):
            for i in range(item.childCount()):
                child = item.child(i)
                gname = child.data(0, GROUP_NAME_ROLE)
                if gname is not None:
                    child_path = path + (gname,)
                    if not child.isExpanded():
                        collapsed.add(child_path)
                    walk(child, child_path)
                else:
                    walk(child, path)
        walk(self._list.invisibleRootItem(), ())
        return collapsed

    def _populate(self):
        selected   = self._selected_theme()
        collapsed  = self._collect_collapsed_groups()
        self._list.clear()
        tc         = self._tc()
        all_themes = set(tc.mapThemes())

        tree = self._load_tree()
        orig = self._collect_themes(tree)
        self._clean_tree(tree, all_themes)
        after_clean = self._collect_themes(tree)
        new_themes  = sorted(all_themes - after_clean, key=str.casefold)
        for name in new_themes:
            tree["children"].append({"type": "theme", "name": name})
        if orig != all_themes or new_themes:
            self._save_tree(tree)

        if not all_themes:
            ph = QTreeWidgetItem(self._list, ["  (no themes in project)"])
            ph.setFlags(ph.flags() & ~ItemIsEnabled)
            ph.setForeground(0, QColor("#999"))
            return

        bold     = QFont(); bold.setBold(True)
        grp_bold = QFont(); grp_bold.setBold(True)
        self._populate_children(self._list.invisibleRootItem(),
                                tree.get("children", []), selected, bold, grp_bold,
                                collapsed, ())
        self._filter(self._search.text())

    def _populate_children(self, parent, children, selected, bold, grp_bold, collapsed=frozenset(), path=()):
        for node in children:
            if node["type"] == "group":
                grp = QTreeWidgetItem(parent, [f"  📁  {node['name']}"])
                grp.setFont(0, grp_bold)
                grp.setForeground(0, QColor("#1a5276"))
                grp.setData(0, UserRole, None)
                grp.setData(0, GROUP_NAME_ROLE, node["name"])
                grp.setFlags(ItemIsEnabled | ItemIsSelectable | ItemIsDragEnabled | ItemIsDropEnabled)
                child_path = path + (node["name"],)
                self._populate_children(grp, node.get("children", []), selected, bold, grp_bold, collapsed, child_path)
                grp.setExpanded(child_path not in collapsed)
            elif node["type"] == "theme":
                name = node["name"]
                item = QTreeWidgetItem(parent, [f"  {name}"])
                item.setData(0, UserRole, name)
                item.setFlags(ItemIsEnabled | ItemIsSelectable | ItemIsDragEnabled)
                if name == self._current_theme:
                    item.setFont(0, bold)
                    item.setForeground(0, QColor("#155724"))
                    item.setBackground(0, QColor("#d4edda"))
                if name == selected:
                    self._list.setCurrentItem(item)

    def _filter(self, text):
        text = text.strip().casefold()
        root = self._list.invisibleRootItem()
        for i in range(root.childCount()):
            self._filter_node(root.child(i), text)

    def _filter_node(self, item, text):
        theme_name = item.data(0, UserRole)
        if theme_name is not None:
            visible = not text or text in theme_name.casefold()
            item.setHidden(not visible)
            return visible
        any_visible = False
        for i in range(item.childCount()):
            if self._filter_node(item.child(i), text):
                any_visible = True
        # When no filter is active, keep groups visible even if empty so the
        # user can see (and drag themes into) newly created empty groups.
        visible = any_visible or not text
        item.setHidden(not visible)
        return visible

    # ── Actions ───────────────────────────────────────────────────────────────

    def _on_item_clicked(self, item, column):
        name = item.data(0, UserRole)
        if not name:
            return
        self._tc().applyTheme(name, self._root(), self._model())
        self.iface.mapCanvas().refresh()
        self._current_theme = name
        self._status.setText(f"✅  Applied: <b>{name}</b>")
        self._populate()

    def _on_add(self):
        tc = self._tc()
        name, ok = QInputDialog.getText(self, "Add Theme", "New theme name:")
        name = name.strip()
        if not ok or not name:
            return
        if name in tc.mapThemes():
            QMessageBox.warning(self, "Already Exists", f"A theme named '{name}' already exists.")
            return
        tc.insert(name, tc.createThemeFromCurrentState(self._root(), self._model()))
        self._status.setText(f"➕  Created: <b>{name}</b>  (from current canvas)")
        self._populate()

    def _on_rename(self):
        item = self._list.currentItem()
        if item is None:
            QMessageBox.warning(self, "Nothing Selected", "Please click a theme or group header first.")
            return
        theme_name = item.data(0, UserRole)
        group_name = item.data(0, GROUP_NAME_ROLE)
        if theme_name is not None:
            tc = self._tc()
            new, ok = QInputDialog.getText(self, "Rename Theme", "New theme name:", text=theme_name)
            new = new.strip()
            if not ok or not new or new == theme_name:
                return
            if new in tc.mapThemes():
                QMessageBox.warning(self, "Already Exists", f"A theme named '{new}' already exists.")
                return
            tc.insert(new, tc.mapThemeState(theme_name))
            tc.removeMapTheme(theme_name)
            tree = self._load_tree()
            self._rename_theme_in_tree(tree, theme_name, new)
            self._save_tree(tree)
            if self._current_theme == theme_name:
                self._current_theme = new
                self._status.setText(f"✅  Applied: <b>{new}</b>")
            self._populate()
        elif group_name:
            new, ok = QInputDialog.getText(self, "Rename Group", "New group name:", text=group_name)
            new = new.strip()
            if not ok or not new or new == group_name:
                return
            tree = self._load_tree()
            self._rename_group_in_tree(tree, group_name, new)
            self._save_tree(tree)
            self._populate()

    def _on_replace(self):
        name = self._require_theme_selection()
        if not name:
            return
        self._replace_theme(name)

    def _replace_theme(self, name):
        reply = QMessageBox.question(
            self, "Replace Theme", f"Overwrite <b>{name}</b> with the current canvas state?",
            Button_Yes | Button_No, Button_No
        )
        if reply != Button_Yes:
            return
        tc = self._tc()
        tc.update(name, tc.createThemeFromCurrentState(self._root(), self._model()))
        self._status.setText(f"🔄  Replaced: <b>{name}</b>")
        self._populate()

    def _on_context_menu(self, pos):
        item = self._list.itemAt(pos)
        name = item.data(0, UserRole) if item is not None else None
        group_name = item.data(0, GROUP_NAME_ROLE) if item is not None else None
        if item is not None:
            self._list.setCurrentItem(item)
        menu = QMenu(self._list)
        act_apply = act_replace = act_rename = act_delete = None
        if name:
            act_apply   = menu.addAction("✅  Apply Theme")
            act_replace = menu.addAction("🔄  Replace with Current Canvas…")
            menu.addSeparator()
            act_rename  = menu.addAction("✏️  Rename…")
            act_delete  = menu.addAction("🗑  Delete…")
            menu.addSeparator()
        elif group_name:
            act_rename  = menu.addAction("✏️  Rename Group…")
            act_delete  = menu.addAction("🗑  Delete Group…")
            menu.addSeparator()
        act_group = menu.addAction("📁  Create Group…")
        chosen = menu.exec_(self._list.viewport().mapToGlobal(pos))
        if chosen is None:
            return
        if chosen is act_group:
            self._on_create_group()
        elif chosen is act_apply:
            self._on_item_clicked(item, 0)
        elif chosen is act_replace:
            self._replace_theme(name)
        elif chosen is act_rename:
            self._on_rename()
        elif chosen is act_delete:
            self._on_delete()

    def _on_delete(self):
        item = self._list.currentItem()
        if item is None:
            QMessageBox.warning(self, "Nothing Selected",
                                "Please click a theme or empty group to delete.")
            return
        theme_name = item.data(0, UserRole)
        if theme_name is None:
            group_name = item.data(0, GROUP_NAME_ROLE)
            if not group_name:
                return
            if item.childCount() > 0:
                QMessageBox.information(self, "Group Not Empty",
                    f"Group <b>{group_name}</b> still contains themes.\n"
                    "Move or delete those themes first, then delete the group.")
                return
            reply = QMessageBox.question(
                self, "Delete Group",
                f"Delete empty group <b>{group_name}</b>?",
                Button_Yes | Button_No, Button_No
            )
            if reply != Button_Yes:
                return
            tree = self._load_tree()
            self._remove_group_from_tree(tree, group_name)
            self._save_tree(tree)
            self._status.setText(f"🗑  Deleted empty group <b>{group_name}</b>")
            self._populate()
            return
        name = theme_name
        reply = QMessageBox.question(
            self, "Delete Theme",
            f"Delete theme <b>{name}</b> from QGIS? This cannot be undone.",
            Button_Yes | Button_No, Button_No
        )
        if reply != Button_Yes:
            return
        self._tc().removeMapTheme(name)
        if self._current_theme == name:
            self._current_theme = None
            self._status.setText("No theme applied yet.")
        self._populate()

    def _on_create_group(self):
        name, ok = QInputDialog.getText(self, "Create Group", "New group name:")
        name = name.strip()
        if not ok or not name:
            return
        tree = self._load_tree()
        if self._find_top_group(tree, name) is not None:
            QMessageBox.warning(self, "Already Exists",
                                f"A group named '{name}' already exists.")
            return
        tree["children"].append({"type": "group", "name": name, "children": []})
        self._save_tree(tree)
        self._status.setText(f"📁  Created empty group <b>{name}</b> — drag themes into it.")
        self._populate()

    def _on_session(self):
        from .dialog_session import SessionDialog
        SessionDialog(self.iface,
                      plugin_version=self._plugin_version(),
                      parent=self.iface.mainWindow()).exec()

    def _plugin_version(self):
        try:
            path = os.path.join(os.path.dirname(__file__), "metadata.txt")
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip().startswith("version="):
                        return line.split("=", 1)[1].strip()
        except Exception:
            pass
        return "?"
